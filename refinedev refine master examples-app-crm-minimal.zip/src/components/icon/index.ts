export * from "./TextIcon";
