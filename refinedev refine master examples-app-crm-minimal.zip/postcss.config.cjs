module.exports = {
  plugins: {
    autoprefixer: {},
    "postcss-nesting": {},
  },
};
